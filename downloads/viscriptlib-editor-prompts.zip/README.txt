VSL editor prompt examples / VSL 编辑器提示词示例

Eight UTF-8 text files for shop, recipe, quest and NPC editors.
Open the corresponding editor, load a practice project and configure your model service before using them. Inspect the actual preview and save separately.

包含商店、配方、任务和 NPC 的中英文提示词。先打开对应编辑器和练习工程，配置自己的模型服务，再复制文字使用。核对实际预览，应用后手动保存。
