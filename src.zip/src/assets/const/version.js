export const chatBoxEditorVersion = '1.0.3'
