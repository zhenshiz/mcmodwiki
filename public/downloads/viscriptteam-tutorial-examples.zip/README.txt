VST 教学示例 / VST tutorial examples

vst_factions.js 放入实例/服务端 kubejs/server_scripts/，需要 KubeJS。它在 ServerEvents.loaded 创建 tutorial_guards 与 tutorial_raiders，并添加双向敌对关系；世界标记 vst_tutorial_factions_v1 防止每次启动重复初始化。首次部署后重启验证。已有同名阵营时不会重置显示名、阈值等已有设置，但会添加这两条敌对关系。
vst_query_helpers.js 只定义函数，供你自己的服务端任务/对话回调调用；它本身不会自动运行或更改声望。回调必须提供 ServerPlayer。
guard-scene-commands.txt 是逐行执行的聊天命令，不是可直接丢进 datapack 的 mcfunction（mcfunction 要去掉行首斜线，且需明确执行位置与玩家身份）。已由初始化脚本创建阵营时跳过前两条 create。
建议使用独立测试世界和非和平难度。命令会生成铁傀儡与尸壳、修改当前玩家声望；先阅读 wiki 的守卫场景及队伍有效声望规则。它不会给所有同类型生物自动分配阵营。

Install vst_factions.js under kubejs/server_scripts/ with KubeJS. On ServerEvents.loaded it creates tutorial_guards/tutorial_raiders and both enemy directions once, guarded by the world flag vst_tutorial_factions_v1. Restart after first installation. Existing faction settings are retained, but the two hostility entries are added.
vst_query_helpers.js defines a function for your own server-side quest/dialogue callback; it does not run automatically. Pass a ServerPlayer.
guard-scene-commands.txt contains chat commands, not a ready-to-run datapack function. Datapack use requires removing leading slashes and specifying execution position/player context. Skip the first two create commands if the init script already created the factions.
Use an isolated, non-Peaceful test world. The commands spawn a golem/husk and change the current player’s standings. Read the guard scenario and party minimum rules first. Other newly spawned mobs are not automatically assigned.
