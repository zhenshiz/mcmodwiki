VSQ 教程示例 / VSQ tutorial examples

包含 sequential（阶段与奖励）、branch（按铁锭数量选路）、all（并行全部完成）、any（并行任选）、timed（8 秒失败与补救）。对应源码 VSQ 1.0.4beta / LDLib2 2.2.45 / NeoForge 1.21.1。

将 ldlib2/ 目录合并到实例/服务器根目录。project 内 .questproj 供编辑器继续编辑；quest 内 .quest 是运行时文件。
执行 /viscript_quests category config，把要测试的逻辑 ID 加入分类，例如 wiki_tutorial/sequential。然后 /viscript_quests grant @s wiki_tutorial/sequential。
发放与分类命令需要管理员权限；编辑器需要权限等级 4。为避免已有任务进度影响结果，请在测试世界使用新任务 ID 或先撤销再重新发放。
示例是教学数据：手动提交会消耗材料，阶段奖励会实际发放；timed 会在目标激活后 8 秒超时。分类配置不会被此包覆盖。

Merge ldlib2/ into the instance/server root. The project .questproj files are editable sources; quest .quest files are compiled runtime assets.
Add a logical ID such as wiki_tutorial/sequential in /viscript_quests category config, then grant it with /viscript_quests grant @s wiki_tutorial/sequential.
Commands require admin permissions; editing requires level 4. Test in a separate world or use fresh IDs/revoke and regrant for clean progress.
Manual submissions consume items and rewards are real. The timed example starts its eight-second deadline at objective activation. Existing category configuration is not replaced.
