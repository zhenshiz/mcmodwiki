<script setup>
import GlobalDialog from '@/views/other/chatBox/components/GlobalModal.vue'
import { Icon } from '@iconify/vue'
import { generateUUID } from '@/utils/format.js'
import { translatable, translatableArg } from '@/assets/translatable/translatable.js'
import { useChatBoxEditorStore, usePageStore } from '@/stores/index.js'
import Modal from '@/components/Modal.vue'
import Input from '@/components/Input.vue'
import { useMessage } from '@/components/register/useMessage.js'
import Switch from '@/components/Switch.vue'

const message = useMessage()
const chatBoxEditorStore = useChatBoxEditorStore()
const lang = computed(() => usePageStore().setting.language)
const dialoguesSetting = computed(() => chatBoxEditorStore.dialoguesSetting)
const EMPTY_DIALOGUES = {
  dialogBox: {
    name: '',
    text: ''
  },
  portrait: [],
  options: [],
  sound: '',
  volume: 1,
  pitch: 1,
  command: ''
}
const isShowSetting = ref(false)
const isShowAddGroup = ref(false)
//记录当前打开的是谁的属性
const key = ref(null)
const index = ref(null)
const expandedGroups = ref({})

const toggleGroup = (groupName) => {
  expandedGroups.value[groupName] = !expandedGroups.value[groupName]
}

const addDialogue = (groupName) => {
  dialoguesSetting.value.dialogues[groupName].push(Object.assign({
    id: generateUUID(),
    top: 30,
    left: 30,
    title: translatableArg(lang.value, 'chat.box.dialogues.custom.title', dialoguesSetting.value.dialogues[groupName].length)
  }, EMPTY_DIALOGUES))
}

const newGroupName = ref('')

const addGroup = () => {
  if (!newGroupName.value) {
    message.warning(translatable(lang.value, 'message.warn.dialogues.group'))
    return
  }

  if (!dialoguesSetting.value.dialogues[newGroupName.value]) {
    dialoguesSetting.value.dialogues[newGroupName.value] = []
    expandedGroups.value[newGroupName.value] = true
    newGroupName.value = ''
    isShowAddGroup.value = false
  }
}

// 空替换，完全移除拖拽相关代码

const closeDialogue = (groupName, index) => {
  dialoguesSetting.value.dialogues[groupName].splice(index, 1)
}

const goto = url => {
  window.open(url, '_blank')
}

const openDialoguesSetting = (groupName, index) => {
  key.value = groupName
  index.value = index

  // 初始化编辑界面的数据
  const dialogue = chatBoxEditorStore.dialoguesSetting[key.value][index.value]
  const dialogBox = dialogue.dialogBox
  const options = dialogue.options

  dialogBox.name = dialogBox.name || ''
  dialogBox.text = dialogBox.text || ''
  options.forEach(option => {
    option.text = option.text || ''
    option.isLock = option.isLock !== undefined ? option.isLock : false
    option.lock = option.lock || { objective: '', value: '' }
    option.isHidden = option.isHidden !== undefined ? option.isHidden : false
    option.hidden = option.hidden || { objective: '', value: '' }
    option.next = option.next !== undefined ? option.next : null
    option.click = option.click || { type: '', value: '' }
    option.tooltip = option.tooltip || ''
  })
  dialogue.sound = dialogue.sound || ''
  dialogue.volume = dialogue.volume !== undefined ? dialogue.volume : 1
  dialogue.pitch = dialogue.pitch !== undefined ? dialogue.pitch : 1
  dialogue.command = dialogue.command || ''
  dialogue.backgroundImage = dialogue.backgroundImage || ''
}
</script>

<template>
  <div class="flex flex-col size-full dark:text-white p-5">
    <div class="mb-5 flex flex-row w-full">
      <div class="flex-1">
        <GlobalDialog />
      </div>
      <div class="flex-1 flex justify-end items-center gap-3">
        <Button is-toggle-color :rounded-size="0" @click="isShowAddGroup=true">
          {{ translatable(lang, 'chat.box.dialogues.add.group') }}
        </Button>
        <Button is-toggle-color :rounded-size="0" @click="()=>isShowSetting=true">
          {{ translatable(lang, 'chat.box.dialogues.common.setting') }}
        </Button>
      </div>
    </div>
    <div class="flex flex-row w-full h-[calc(100vh-165px)] max-h-[calc(100vh-165px)]">
      <div class="border flex-[4] overflow-auto relative p-4">
        <div class="space-y-3">
          <div
            v-for="(dialogues, groupName) in dialoguesSetting.dialogues"
            :key="groupName"
            class="border rounded-lg overflow-hidden"
          >
            <!-- 分组标题 -->
            <div
              class="flex items-center justify-between p-3 bg-gray-100 dark:bg-gray-700 cursor-pointer"
              @click="toggleGroup(groupName)"
            >
              <h3 class="font-medium">{{ groupName }}</h3>
              <div class="flex items-center space-x-2">
                <Icon
                  :icon="expandedGroups[groupName] ? 'mdi:chevron-down' : 'mdi:chevron-right'"
                  class="text-lg"
                />
                <span class="text-sm text-gray-500">
                  {{ dialogues.length }} {{ translatable(lang, 'chat.box.dialogues.count') }}
                </span>
                <Button is-toggle-color class="w-[30px] h-[30px] center"
                        @click.stop="addDialogue(groupName)">
                  +
                </Button>
              </div>
            </div>

            <!-- 分组内容 -->
            <div v-if="expandedGroups[groupName]" class="p-3 space-y-2">
              <div
                v-for="(node, index) in dialogues"
                :key="index"
                class="flex justify-between items-center p-2 border rounded mb-2 cursor-pointer hover:bg-gray-50 hover:text-text-blue"
                @click="openDialoguesSetting(groupName, index)"
              >
                <span class="font-medium">{{ node.dialogBox?.name || `对话 ${index + 1}` }}</span>
                <div class="flex items-center space-x-2">
                    <span class="text-sm text-gray-500 truncate" :title="node.dialogBox?.text">
                      {{ node.dialogBox?.text || '未设置内容' }}
                    </span>
                  <Icon
                    icon="mdi:close"
                    class="text-gray-500 hover:text-red-500"
                    @click.stop="closeDialogue(groupName, index)"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 右侧编辑界面 -->
      <div class="border flex-1 overflow-auto p-4 dark:bg-gray-800">
        <div v-if="key !== null && index !== null" class="space-y-4">
          <h3 class="text-lg font-medium">{{ translatable(lang, 'chat.box.dialogues.edit.title')
            }}</h3>

          <!-- 对话框基础配置 -->
          <div>
            <label class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.dialogBox.name')
              }}</label>
            <Input
              v-model="chatBoxEditorStore.dialoguesSetting[key][index].dialogBox.name"
              :placeholder="translatable(lang, 'chat.box.dialogues.dialogBox.name')"
            />
          </div>

          <div>
            <label class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.dialogBox.text')
              }}</label>
            <Input
              v-model="chatBoxEditorStore.dialoguesSetting[key][index].dialogBox.text"
              type="textarea"
              :placeholder="translatable(lang, 'chat.box.dialogues.dialogBox.text')"
            />
          </div>

          <!-- 立绘 -->
          <div>
            <label class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.portrait')
              }}</label>
            <Input
              v-model="chatBoxEditorStore.dialoguesSetting[key][index].portrait"
              type="textarea"
              :placeholder="translatable(lang, 'chat.box.dialogues.portrait')"
            />
          </div>

          <!-- 选项配置 -->
          <div>
            <label class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.options') }}</label>
            <div class="space-y-2">
              <div
                v-for="(option, optIndex) in chatBoxEditorStore.dialoguesSetting[key][index].options"
                :key="optIndex"
                class="p-2 border rounded"
              >
                <div>
                  <label class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.options.text')
                    }}</label>
                  <Input
                    v-model="option.text"
                    :placeholder="translatable(lang, 'chat.box.dialogues.options.text')"
                  />
                </div>

                <div>
                  <label
                    class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.options.isLock')
                    }}</label>
                  <Switch v-model="option.isLock" />
                </div>

                <div v-if="option.isLock">
                  <label
                    class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.options.lock.objective')
                    }}</label>
                  <Input
                    v-model="option.lock.objective"
                    :placeholder="translatable(lang, 'chat.box.dialogues.options.lock.objective')"
                  />

                  <label
                    class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.options.lock.value')
                    }}</label>
                  <Input
                    v-model="option.lock.value"
                    :placeholder="translatable(lang, 'chat.box.dialogues.options.lock.value')"
                  />
                </div>

                <div>
                  <label
                    class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.options.isHidden')
                    }}</label>
                  <Switch v-model="option.isHidden" />
                </div>

                <div v-if="option.isHidden">
                  <label
                    class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.options.hidden.objective')
                    }}</label>
                  <Input
                    v-model="option.hidden.objective"
                    :placeholder="translatable(lang, 'chat.box.dialogues.options.hidden.objective')"
                  />

                  <label
                    class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.options.hidden.value')
                    }}</label>
                  <Input
                    v-model="option.hidden.value"
                    :placeholder="translatable(lang, 'chat.box.dialogues.options.hidden.value')"
                  />
                </div>

                <div>
                  <label class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.options.next')
                    }}</label>
                  <Input
                    v-model="option.next"
                    type="number"
                    :placeholder="translatable(lang, 'chat.box.dialogues.options.next')"
                  />
                </div>

                <div>
                  <label
                    class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.options.click.type')
                    }}</label>
                  <Input
                    v-model="option.click.type"
                    :placeholder="translatable(lang, 'chat.box.dialogues.options.click.type')"
                  />

                  <label
                    class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.options.click.value')
                    }}</label>
                  <Input
                    v-model="option.click.value"
                    :placeholder="translatable(lang, 'chat.box.dialogues.options.click.value')"
                  />
                </div>

                <div>
                  <label
                    class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.options.tooltip')
                    }}</label>
                  <Input
                    v-model="option.tooltip"
                    :placeholder="translatable(lang, 'chat.box.dialogues.options.tooltip')"
                  />
                </div>
              </div>
            </div>
            <Button
              size="sm"
              class="mt-2"
              @click="chatBoxEditorStore.dialoguesSetting[key][index].options.push({ text: '' })"
            >
              {{ translatable(lang, 'chat.box.dialogues.option.add') }}
            </Button>
          </div>

          <!-- 音效和命令 -->
          <div>
            <label class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.sound') }}</label>
            <Input
              v-model="chatBoxEditorStore.dialoguesSetting[key][index].sound"
              :placeholder="translatable(lang, 'chat.box.dialogues.sound')"
            />
          </div>

          <div>
            <label class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.volume') }}</label>
            <Input
              v-model.number="chatBoxEditorStore.dialoguesSetting[key][index].volume"
              type="number"
              :placeholder="translatable(lang, 'chat.box.dialogues.volume')"
            />
          </div>

          <div>
            <label class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.pitch') }}</label>
            <Input
              v-model.number="chatBoxEditorStore.dialoguesSetting[key][index].pitch"
              type="number"
              :placeholder="translatable(lang, 'chat.box.dialogues.pitch')"
            />
          </div>

          <div>
            <label class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.command') }}</label>
            <Input
              v-model="chatBoxEditorStore.dialoguesSetting[key][index].command"
              :placeholder="translatable(lang, 'chat.box.dialogues.command')"
            />
          </div>

          <div>
            <label class="block mb-1">{{ translatable(lang, 'chat.box.dialogues.backgroundImage')
              }}</label>
            <Input
              v-model="chatBoxEditorStore.dialoguesSetting[key][index].backgroundImage"
              :placeholder="translatable(lang, 'chat.box.dialogues.backgroundImage')"
            />
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--新增分组-->
  <Modal :title="translatable(lang,'chat.box.dialogues.add.group')" :show="isShowAddGroup"
         :defaultCloseEvent="['onClose', 'onNegativeClick']"
         @defaultClose="arg=>isShowAddGroup=false" @onPositiveClick="addGroup"
         :sm-width="30">
    <template #content>
      <div class="center w-full h-[200px] dark:text-white">
        <div class="flex flex-row items-center whitespace-nowrap">
          {{ translatable(lang, 'chat.box.dialogues.group.name') }}
          <Input
            class="mr-2"
            v-model="newGroupName"
            defaultModel="search"
          />
        </div>
      </div>
    </template>
  </Modal>
  <!--对话框基础配置-->
  <Modal :title="translatable(lang,'chat.box.dialogues.common.setting')" :show="isShowSetting"
         :positive-visible="false" :negative-visible="false" @onClose="args => isShowSetting=false">
    <template #content>
      <div class="flex flex-col justify-center w-full dark:text-white">
        <div class="flex flex-col gap-3">
          <div class="flex flex-row items-center whitespace-nowrap">
            {{ translatable(lang, 'chat.box.dialogues.introduce') }}
            <Input
              class="mr-2"
              v-model="dialoguesSetting.$introduce"
              defaultModel="search"
            />
          </div>
          <div class="flex flex-row items-center whitespace-nowrap">
            {{ translatable(lang, 'chat.box.dialogues.isTranslatable') }}
            <Switch v-model="dialoguesSetting.isTranslatable" />
          </div>
          <div class="flex flex-row items-center whitespace-nowrap">
            {{ translatable(lang, 'chat.box.dialogues.isEsc') }}
            <Switch v-model="dialoguesSetting.isEsc" />
          </div>
          <div class="flex flex-row items-center whitespace-nowrap">
            {{ translatable(lang, 'chat.box.dialogues.isPause') }}
            <Switch v-model="dialoguesSetting.isPause" />
          </div>
          <div class="flex flex-row items-center whitespace-nowrap">
            {{ translatable(lang, 'chat.box.dialogues.isHistoricalSkip') }}
            <Switch v-model="dialoguesSetting.isHistoricalSkip" />
          </div>
          <div class="flex flex-row items-center whitespace-nowrap">
            {{ translatable(lang, 'chat.box.dialogues.maxTriggerCount') }}
            <Input
              class="mr-2"
              v-model="dialoguesSetting.maxTriggerCount"
              defaultModel="search"
            />
          </div>
          <div class="flex flex-row items-center whitespace-nowrap">
            {{ translatable(lang, 'chat.box.dialogues.criteria') }}
            <Button is-toggle-color :rounded-size="0"
                    @click="goto('https://misode.github.io/advancement/')">
              {{ translatable(lang, 'chat.box.dialogues.criteria.button') }}
            </Button>
          </div>
        </div>
      </div>
    </template>
  </Modal>
</template>
