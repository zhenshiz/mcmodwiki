export const webHref = {
  'github': 'https://github.com/zhenshiz/mcmodwiki',
  'translatable': 'https://github.com/zhenshiz/mcmodwiki/blob/master/src/assets/translatable/translatable.js'
}
