export function getDefaultIfInvalid(value, defaultValue) {
  return (value === undefined || Number.isNaN(value)) ? defaultValue : value
}

export function isNumber(value) {
  return !isNaN(Number(value))
}
