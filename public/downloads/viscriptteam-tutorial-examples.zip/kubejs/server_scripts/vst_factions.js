// kubejs/server_scripts/vst_factions.js
ServerEvents.loaded(event => {
  const server = event.server
  const state = server.persistentData
  if (state.getBoolean('vst_tutorial_factions_v1')) return

  const level = server.overworld()
  const vst = Java.loadClass('com.viscript_team.util.ViScriptTeamServerUtil')
  vst.createFaction(level, 'tutorial_guards')
  vst.createFaction(level, 'tutorial_raiders')
  vst.addEnemyFaction(level, 'tutorial_guards', 'tutorial_raiders')
  vst.addEnemyFaction(level, 'tutorial_raiders', 'tutorial_guards')

  state.putBoolean('vst_tutorial_factions_v1', true)
})
