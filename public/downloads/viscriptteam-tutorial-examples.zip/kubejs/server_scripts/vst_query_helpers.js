// Call from your own server-side quest or dialogue callback.
function inspectGuardStanding(player) {
  const vst = Java.loadClass('com.viscript_team.util.ViScriptTeamServerUtil')
  const personal = vst.getPlayerStanding(player, 'tutorial_guards')
  const effective = vst.getPlayerEffectiveStanding(player, 'tutorial_guards')
  const partyId = vst.getPlayerPartyId(player)
  player.tell('Personal: ' + personal + ' | Effective: ' + effective)
  if (partyId == null) return

  const leaderValue = vst.getPartyEffectiveStanding(
    player.serverLevel(), partyId, 'tutorial_guards', 'leader'
  )
  player.tell('Party: ' + partyId + ' | Leader strategy: ' + leaderValue)
}
